<?php
	error_reporting(E_ALL);
	ini_set('display_errors', 'on');
	session_start();
	
	if (!empty($_POST)) {
		if ($_POST['capcha'] === $_SESSION['capcha']) {
			echo '<p id="sum">';
				echo $_POST['num1'] + $_POST['num2'];
			echo '</p>';
		} else {
			echo 'капча введена не верно';
		}
		
	}
?>

<form action="" method="POST">
	<input name="num1" placeholder="число 1">
	<input name="num2" placeholder="число 2">
	<img src="capcha.php">
	<input name="capcha" placeholder="капча">
	<input type="submit">
</form>
