<?php
	session_start();
	
	$capchas = [
		'DkxXP', 'LSYXk', 'N4WW', 'NMXdVV', 'WXPGV', 
	];
	
	$capcha = $capchas[array_rand($capchas)];
	
	$_SESSION['capcha'] = $capcha;
	
	header("Content-Type: image/png");
	
	$file = fopen("capchas/$capcha.png", 'r', false);
	$response = stream_get_contents($file);
	fclose($file);
	
	exit($response);