<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>главная страница</title>
	</head>
	<body>
		<?php if ($_SESSION['auth']) { ?>
			<nav>
				<a href="/page1.php">1</a>
				<a href="/page2.php">2</a>
				<a href="/page3.php">3</a>
				<a href="/page4.php">4</a>
				<a href="/page5.php">5</a>
			</nav>
		<?php } else { ?>
			авторизуйтесь, чтобы получить
			доступ к странице
		<?php } ?>
	<body>
</html>