<?php
	session_start();
	
	$login = 'user';
	$pass  = '12345';
	
	if (!empty($_POST)) {
		if ($_POST['login'] === $login and $_POST['pass'] === $pass) {
			$_SESSION['auth'] = true;
			echo 'вы успешно авторизованы';
		} else {
			echo 'неверный логин или пароль';
		}
	}
?>
<form action="" method="POST">
	<input name="login" placeholder="логин">
	<input name="pass"  placeholder="пароль">
	<input type="submit">
</form>