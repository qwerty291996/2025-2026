<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>страница 5</title>
	</head>
	<body>
		<?php
			session_start();
			
			if ($_SESSION['auth']) {
				echo '<p id="content">';
					echo 'закрытый контент страницы 5';
				echo '</p>';
			} else {
				echo 'у вас нет доступа';
			}
		?>
	<body>
</html>