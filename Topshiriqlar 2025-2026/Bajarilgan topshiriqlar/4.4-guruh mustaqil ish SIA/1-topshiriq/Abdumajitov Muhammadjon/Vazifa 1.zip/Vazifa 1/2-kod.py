n = int(input("n ni kiriting (n > 0): "))
S = 1.0
for i in range(1, n + 1):
    S *= (1 + 0.1 * i)
print("Natija:", S)
