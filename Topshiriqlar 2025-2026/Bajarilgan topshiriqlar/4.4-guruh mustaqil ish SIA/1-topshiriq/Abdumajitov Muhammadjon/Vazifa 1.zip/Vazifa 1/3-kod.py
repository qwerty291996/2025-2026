decimal_str = input("Butun musbat sonni kiriting: ")
decimal_num = int(decimal_str)
binary_str = bin(decimal_num)[2:]  
print("Ikkilik sanoq sistemasidagi qiymati:", binary_str)
