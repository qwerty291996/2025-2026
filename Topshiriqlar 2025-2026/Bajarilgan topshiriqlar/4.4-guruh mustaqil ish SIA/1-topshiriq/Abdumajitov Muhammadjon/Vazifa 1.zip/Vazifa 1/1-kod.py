def bir_xil_rangda(x1, y1, x2, y2):
    # Tekshiruv: ikkita maydon bir xil rangda bo'lsa True qaytaradi
    return ((x1 + y1) % 2) == ((x2 + y2) % 2)

def main():
    print("8x8 shaxmat doskasidagi maydonlarning rangini tekshiruvchi dastur.\nBarcha koordinatalar 1-8 gacha bo'lishi kerak!")
    
    # Koordinatalarni qabul qilish
    x1 = int(input("Birinchi maydonning x1 koordinatasi : "))
    y1 = int(input("Birinchi maydonning y1 koordinatasi : "))
    x2 = int(input("Ikkinchi maydonning x2 koordinatasi : "))
    y2 = int(input("Ikkinchi maydonning y2 koordinatasi : "))
    
    if not (1 <= x1 <= 8 and 1 <= y1 <= 8 and 1 <= x2 <= 8 and 1 <= y2 <= 8):
        print("Xato: barcha koordinatalar 1 dan 8 gacha bo'lishi kerak.")
        return

    if (x1, y1) == (x2, y2):
        print("Xato: Ikkita turli maydon koordinatalari berilishi kerak.")
        return

    if bir_xil_rangda(x1, y1, x2, y2):
        print("Berilgan maydonilar bir xil rangda.")
    else:
        print("Berilgan maydonilar turli ranglarda.")

if __name__ == "__main__":
    main()
